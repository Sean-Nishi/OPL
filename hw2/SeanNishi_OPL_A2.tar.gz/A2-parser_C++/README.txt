README file for Assignment 2

Sean Nishi
February 2018

I was unable to to make the test target in the Makefile because I don't know how to open a calculator program file and tokenize each line to be fed into input_token. So the program only accepts input from the command line, just like the initial program assigned to us.

The exception handling is supposed to read tokens until it finds the expected token, then continues parsing the program.

I was also unable to print out the total calculator program after the program finishes reading input.
